"""
Q1. Gemini Integration and Intelligent Summarization
Author: Champ
"""

import google.generativeai as genai
import requests
from bs4 import BeautifulSoup
import os

# -----------------------------
# STEP 1: Configure Gemini API
# -----------------------------
genai.configure(api_key=os.getenv("GEMINI_API_KEY"))

# Use Gemini 2.5 Flash
model = genai.GenerativeModel("gemini-2.5-flash")

# -----------------------------
# STEP 2: Fetch Webpage
# -----------------------------
url = "https://en.wikipedia.org/wiki/Artificial_intelligence"  # You can change to BBC/CNN

print(f"🔗 Fetching webpage: {url}\n")
response = requests.get(url, timeout=30)
html_content = response.text

# -----------------------------
# STEP 3: Clean HTML Content
# -----------------------------
soup = BeautifulSoup(html_content, "html.parser")

# Remove unwanted tags
for tag in soup(["script", "style", "nav", "footer", "header", "aside"]):
    tag.decompose()

# Extract clean text
text = " ".join(soup.stripped_strings)
clean_text = text[:10000]  # Limit to first 10k chars (API-friendly)

print("✅ Webpage content fetched and cleaned successfully.\n")

# -----------------------------
# STEP 4: Create Intelligent Prompt
# -----------------------------
prompt = f"""
You are an AI analyst. Analyze the following webpage content and provide:

1. A concise summary (5-6 sentences)
2. 1 short analytical insight about trends, implications, or significance.

Avoid repetition. Keep it factual and insightful.

Webpage Content:
{clean_text}
"""

# -----------------------------
# STEP 5: Send to Gemini API
# -----------------------------
print("🤖 Sending content to Gemini 2.5 Flash for summarization...\n")

response = model.generate_content(prompt)

# -----------------------------
# STEP 6: Print the Output
# -----------------------------
print("=== 🌐 GEMINI INTELLIGENT SUMMARY OUTPUT ===\n")
print(response.text)
print("\n============================================")
