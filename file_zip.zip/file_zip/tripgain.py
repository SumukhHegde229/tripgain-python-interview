# # Section 1

# # Q1. Load the dataset into a pandas DataFrame and show:---------
# import pandas as pd
# df=pd.read_csv(r"C:\Users\SUMUKH HEGDE\Downloads\matches.csv")

# print("Question 1: ")
# # print(df.head())

# # • Total number of matches
# print(df['Season'].value_counts().sum())

# # # • Column names
# print(df.columns)
# # # • First 5 rows of data
# print(df.head())
# # # • Describe the data
# print(df.describe())

# # Q2. Which player has won the most “Player of the Match” awards in games decided on the final ball?
# #  (i.e., matches won by just 1 run or 1 wicket

# print()
# print("Question 2: Which player has won the most “Player of the Match” awards in games decided on the final ball?")
# print(df['player_of_match'][(df['win_by_runs']==1)|(df['win_by_wickets']==1)].max())


# # Q3. At Wankhede Stadium, is it more common to win by batting first (runs) or by batting second
# # (wickets)?

# # print(df['venue']=='Wankhede')


# # Q4. Which team has the highest number of wins where the victory margin was greater than 50 runs?----------------
# print()
# print("Question 4: Which team has the highest number of wins where the victory margin was greater than 50 runs?")
# print(df['winner'][df['win_by_runs']>50].max())


# #Q5. How many times has the team that won the toss also set a target and won the match?  ----------
# print()
# print("Q5: How many times has the team that won the toss also set a target and won the match?")
# print(df[(df['toss_winner']==df['winner']) & (df['toss_decision']=='bat')].value_counts().sum())

#Q6. Which of the two umpires (umpire1 or umpire2) has officiated more matches involving the
# Kolkata Knight Riders? 

# print(df[((df['umpire1'][((df['team1']=='Kolkata Knight Riders')|(df['team2']=='Kolkata Knight Riders'))])) | (df['umpire2'][((df['team1']=='Kolkata Knight Riders')|(df['team2']=='Kolkata Knight Riders'))])]).head(1)



#Section 2

#Q1
# flight_search_automation.py
# from playwright.sync_api import sync_playwright
# import time

# def run_flight_search():
#     with sync_playwright() as p:
#         browser = p.chromium.launch(headless=False, slow_mo=250)
#         page = browser.new_page()

#         # Step 1: Load site
#         page.goto("https://www.budgetticket.in", timeout=60000)
#         page.wait_for_load_state("domcontentloaded")

#         # Step 2: Wait for 'From' field (handles new selector patterns too)
#         page.wait_for_selector("input[id*='from'], input[placeholder*='From']", timeout=60000)

#         origin_input = page.locator("input[id*='from'], input[placeholder*='From']").first
#         origin_input.click()
#         origin_input.fill("Bangalore")
#         time.sleep(2)

#         page.wait_for_selector("//ul[contains(@class,'ui-autocomplete')]/li", timeout=10000)
#         page.locator("//ul[contains(@class,'ui-autocomplete')]/li").first.click()

#         print("✅ From city entered successfully!")

#         time.sleep(5)
#         browser.close()

# if __name__ == "__main__":
#     run_flight_search()


from playwright.sync_api import sync_playwright
from datetime import datetime
import time

def run_flight_search():
    with sync_playwright() as p:
        browser = p.chromium.launch(headless=False, slow_mo=250)
        page = browser.new_page()

        # === Step 1: Load website ===
        page.goto("https://www.budgetticket.in", timeout=60000)
        page.wait_for_load_state("domcontentloaded")
        page.wait_for_selector("input[placeholder*='ORIGIN'], input[placeholder*='From']", timeout=60000)

        # === Step 2: Set Origin ===
        origin_city = "Bangalore"
        origin_input = page.locator("input[placeholder*='ORIGIN'], input[placeholder*='From']").first
        origin_input.click()
        origin_input.fill(origin_city)
        time.sleep(2)
        page.wait_for_selector("//ul[contains(@class,'ui-autocomplete')]/li", timeout=10000)
        page.locator("//ul[contains(@class,'ui-autocomplete')]/li").first.click()

        # === Step 3: Set Destination ===
        destination_city = "Delhi"
        dest_input = page.locator("input[placeholder*='DESTINATION'], input[placeholder*='To']").first
        dest_input.click()
        dest_input.fill(destination_city)
        time.sleep(2)
        page.wait_for_selector("//ul[contains(@class,'ui-autocomplete')]/li", timeout=10000)
        page.locator("//ul[contains(@class,'ui-autocomplete')]/li").first.click()

        # === Step 4: Pick Date ===
        page.locator("input[placeholder*='Departure']").click()
        page.wait_for_selector("//table[contains(@class,'ui-datepicker-calendar')]//a", timeout=10000)
        page.locator("//table[contains(@class,'ui-datepicker-calendar')]//a").first.click()

        # === Step 5: Click Search ===
        page.wait_for_selector("//button[contains(text(),'Search')]", timeout=10000)
        page.locator("//button[contains(text(),'Search')]").click()
        page.wait_for_timeout(8000)

        # === Step 6: Add metadata fields ===
        search_datetime = datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S UTC")

        data_record = {
            "searchdatetime": search_datetime,
            "origin": origin_city,
            "destination": destination_city
        }

        print("✅ Flight search completed successfully!")
        print("📄 Auto-added fields:", data_record)

        time.sleep(3)
        browser.close()


if __name__ == "__main__":
    run_flight_search()






#Q2
# import json
# from datetime import datetime

# def extract_flight_details(page, journey_date):
#     flights = []
#     flight_elements = page.query_selector_all(".flight-list-item")

#     for flight in flight_elements:
#         airline = flight.query_selector(".airline-name")
#         flight_no = flight.query_selector(".flight-number")
#         dep_time = flight.query_selector(".depart-time")
#         arr_time = flight.query_selector(".arrival-time")
#         price = flight.query_selector(".flight-price")

#         flights.append({
#             "airline": airline.inner_text().strip() if airline else "N/A",
#             "flight_number": flight_no.inner_text().strip() if flight_no else "N/A",
#             "departure_time": dep_time.inner_text().strip() if dep_time else "N/A",
#             "arrival_time": arr_time.inner_text().strip() if arr_time else "N/A",
#             "price": price.inner_text().strip() if price else "N/A",
#             "journey_date": journey_date
#         })

#     # Save extracted results to JSON
#     with open("flight_results.json", "w", encoding="utf-8") as f:
#         json.dump(flights, f, indent=4, ensure_ascii=False)

#     print(f"✅ Saved {len(flights)} flight results to flight_results.json")
#     return flights


# # Q3
# from datetime import datetime

# def add_extra_fields(flights):
#     for flight in flights:
#         flight["searchdatetime"] = datetime.utcnow().isoformat()
#         flight["origin"] = "Bangalore"
#         flight["destination"] = "Delhi"
#     return flights


# #Q4
# import json
# from datetime import datetime
# from playwright.sync_api import sync_playwright

# def main():
#     with sync_playwright() as p:
#         browser = p.chromium.launch(headless=False)
#         page = browser.new_page()

#         # Open website
#         page.goto("https://www.budgetticket.in", timeout=60000)

#         # Input fields
#         origin = "Bangalore"
#         destination = "Delhi"
#         journey_date = (datetime.now().date().replace(day=datetime.now().day + 7)).strftime("%d-%m-%Y")

#         page.fill("#fromPlaceName", origin)
#         page.fill("#toPlaceName", destination)
#         page.fill("#txtDepartDate", journey_date)

#         # Search Flights
#         page.click("#btnSearchFlight")
#         page.wait_for_selector(".flight-list-item", timeout=60000)

#         # Extract flight results
#         flights = []
#         flight_elements = page.query_selector_all(".flight-list-item")

#         for flight in flight_elements:
#             airline = flight.query_selector(".airline-name")
#             flight_no = flight.query_selector(".flight-number")
#             dep_time = flight.query_selector(".depart-time")
#             arr_time = flight.query_selector(".arrival-time")
#             price = flight.query_selector(".flight-price")

#             flights.append({
#                 "airline": airline.inner_text().strip() if airline else "N/A",
#                 "flight_number": flight_no.inner_text().strip() if flight_no else "N/A",
#                 "departure": dep_time.inner_text().strip() if dep_time else "N/A",
#                 "arrival": arr_time.inner_text().strip() if arr_time else "N/A",
#                 "price": price.inner_text().strip() if price else "N/A",
#                 "origin": origin,
#                 "destination": destination,
#                 "searchdatetime": datetime.utcnow().isoformat()
#             })

#         # Save results to flight_results.json
#         with open("flight_results.json", "w", encoding="utf-8") as f:
#             json.dump(flights, f, indent=4, ensure_ascii=False)

#         print(f"✅ flight_results.json saved successfully!")
#         print(f"Total Flights Extracted: {len(flights)}")

#         browser.close()

# if __name__ == "__main__":
#     main()


# #Q5
# from fastapi import FastAPI, Query
# from playwright.sync_api import sync_playwright
# from datetime import datetime

# app = FastAPI(title="Flight Search Automation API")

# @app.get("/flight-search")
# def flight_search(
#     origin: str = Query(..., description="Origin city"),
#     destination: str = Query(..., description="Destination city"),
#     journey_date: str = Query(..., description="Journey date in YYYY-MM-DD format")
# ):
#     """
#     Runs Playwright to scrape flight details dynamically and return as JSON.
#     Example:
#     GET /flight-search?origin=Bangalore&destination=Delhi&journey_date=2025-10-18
#     """
#     with sync_playwright() as p:
#         browser = p.chromium.launch(headless=True)
#         page = browser.new_page()

#         # Open website
#         page.goto("https://www.budgetticket.in", timeout=60000)

#         # Fill details
#         page.fill("#fromPlaceName", origin)
#         page.fill("#toPlaceName", destination)

#         # Convert date format if required (DD-MM-YYYY)
#         date_obj = datetime.strptime(journey_date, "%Y-%m-%d")
#         formatted_date = date_obj.strftime("%d-%m-%Y")
#         page.fill("#txtDepartDate", formatted_date)

#         # Search flights
#         page.click("#btnSearchFlight")
#         page.wait_for_selector(".flight-list-item", timeout=60000)

#         # Extract flight details
#         flights = []
#         flight_elements = page.query_selector_all(".flight-list-item")

#         for flight in flight_elements:
#             airline = flight.query_selector(".airline-name")
#             flight_no = flight.query_selector(".flight-number")
#             dep_time = flight.query_selector(".depart-time")
#             arr_time = flight.query_selector(".arrival-time")
#             price = flight.query_selector(".flight-price")

#             flights.append({
#                 "airline": airline.inner_text().strip() if airline else "N/A",
#                 "flight_number": flight_no.inner_text().strip() if flight_no else "N/A",
#                 "departure": dep_time.inner_text().strip() if dep_time else "N/A",
#                 "arrival": arr_time.inner_text().strip() if arr_time else "N/A",
#                 "price": price.inner_text().strip() if price else "N/A",
#                 "origin": origin,
#                 "destination": destination,
#                 "searchdatetime": datetime.utcnow().isoformat()
#             })

#         browser.close()
#         return flights






